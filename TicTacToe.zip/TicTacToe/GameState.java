package TicTacToe;

public enum GameState
{
    // The winning state is for player 1
    WIN,
    // The losing state is for player 2
    LOSE,
    NOT_END,

    TIE
}
