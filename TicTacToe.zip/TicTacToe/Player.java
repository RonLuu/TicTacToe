package TicTacToe;

public enum Player
{
    PLAYER,
    BOT
}
